import './App.css';

import Foot from './component/foot';

function App() {
  return (
    <div className="App">
      <Foot/>
    </div>
  );
}

export default App;
